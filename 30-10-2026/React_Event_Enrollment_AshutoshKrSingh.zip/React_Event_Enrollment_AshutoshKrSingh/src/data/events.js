// Fixed starter dataset. Dates/times are interpreted in the browser's local time.
export const EVENTS = [
  { id: 'EV101', title: 'Intro to Cloud Computing', category: 'Technology', date: '2026-11-10', time: '10:00', seats: 4 },
  { id: 'EV102', title: 'Creative Writing Lab', category: 'Arts', date: '2026-11-12', time: '14:00', seats: 3 },
  { id: 'EV103', title: 'Data Visualization Basics', category: 'Technology', date: '2026-11-14', time: '11:00', seats: 5 },
  { id: 'EV104', title: 'Personal Finance Essentials', category: 'Life Skills', date: '2026-11-16', time: '16:00', seats: 4 },
  { id: 'EV105', title: 'Public Speaking Practice', category: 'Life Skills', date: '2026-11-18', time: '10:30', seats: 3 },
  { id: 'EV106', title: 'Digital Illustration Studio', category: 'Arts', date: '2026-11-20', time: '13:00', seats: 2 },
]

export const CATEGORIES = ['All', 'Technology', 'Arts', 'Life Skills']
