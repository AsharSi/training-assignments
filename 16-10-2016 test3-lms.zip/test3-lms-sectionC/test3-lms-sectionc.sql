SELECT * FROM parts;

SELECT * FROM parts WHERE unit_price > 1000;

SELECT category, ROUND(AVG(unit_price), 2) FROM parts GROUP BY category;

SELECT category, SUM(stock_qty) FROM parts GROUP BY category;

SELECT s.supplier_name, po.order_date, po.status FROM purchase_orders po JOIN suppliers s ON s.supplier_id = po.supplier_id;

SELECT poi.po_id, p.part_name, poi.quantity, p.unit_price FROM purchase_order_items poi JOIN purchase_orders po ON po.po_id = poi.po_id JOIN parts p ON poi.part_id = p.part_id;

SELECT poi.po_id, p.part_name, poi.quantity, p.unit_price, (poi.quantity * p.unit_price) AS line_total FROM purchase_order_items poi JOIN purchase_orders po ON po.po_id = poi.po_id JOIN parts p ON poi.part_id = p.part_id;

SELECT * FROM suppliers s LEFT JOIN purchase_orders po ON s.supplier_id = po.supplier_id;

SELECT * FROM suppliers s LEFT JOIN purchase_orders po ON s.supplier_id = po.supplier_id WHERE po_id IS NULL;

DROP VIEW purchase_order_summary;

CREATE VIEW purchase_order_summary AS
SELECT po.po_id, s.supplier_name, p.part_name, poi.quantity, p.unit_price, (p.unit_price * poi.quantity) AS line_total, po.status
FROM purchase_order_items poi
JOIN purchase_orders po ON poi.po_id = po.po_id
JOIN parts p ON poi.part_id = p.part_id
JOIN suppliers s ON po.supplier_id = s.supplier_id;

SELECT * FROM purchase_order_summary;

CREATE OR REPLACE FUNCTION calculate_part_discount(
	amount NUMERIC(18, 2)
)
RETURNS NUMERIC(18, 2) 
AS $$
DECLARE returnAmt NUMERIC(18, 2);
BEGIN 
	IF amount >= 2000 THEN
		returnAmt := amount * 0.1;
	ELSE 
		returnAmt := 0;
	END IF;
	
	RETURN returnAmt;
END;
$$ LANGUAGE plpgsql;

SELECT *, calculate_part_discount(unit_price) AS discount FROM parts;
	
CREATE OR REPLACE FUNCTION final_part_price(
	amount NUMERIC(18, 2)
)
RETURNS NUMERIC(18, 2) 
AS $$
DECLARE returnAmt NUMERIC(18, 2);
BEGIN 	
	RETURN amount - calculate_part_discount(amount);
END;
$$ LANGUAGE plpgsql;

SELECT *, final_part_price(unit_price) AS final_part_price FROM parts;

CREATE OR REPLACE PROCEDURE update_po_status(
	p_po_id INT,
	new_status VARCHAR(30)
)
LANGUAGE plpgsql
AS $$
BEGIN
	UPDATE purchase_orders
	SET status = new_status
	WHERE po_id = p_po_id;
END;
$$;



CREATE OR REPLACE PROCEDURE mark_old_pending_orders()
LANGUAGE plpgsql
AS $$
BEGIN
	UPDATE purchase_orders
	SET status = "Received"
	WHERE order_date < '2026-10-04';
END;
$$;

-- CALL update_po_status(1001, 'Cancelled');

-- CALL mark_old_pending_orders()