# Answer B5

Cloud infrastructure refers to the services which are accessible over the internet and are provided by various cloud providers such as AWS, Azure, GCP, Cloudflare, Oracle. We need not to maintain our own hardware/infrastructure.

On-premise infrastructure refers to the systems where entity have their own servers to maintain their services. They would not have to rely on others and this in turn will protect the data that is shared to cloud providers. The major drawback of this is that the entity have to bear huge upfront cost and maintenance along with it.


# Answer B6

Azure subscription helps create a billing for the resources that are created by using the subscription for using Azure Services. Which in turn leads to every resource creation needs azure subscription. We can create multiple subscriptions and separate each subscription for each type of resources. This will also enhace security as one subscription can be given to one team separating other subscription which current team doesn't need access.


# Answer B7

A resource group is like a folder where different files are stored. In Azure resource group contains various services allotted to it. Weather it is web services or database or VM all can be included into the resource group. RBAC is also happens at the Resource group level as it is more convenient.


# Answer B8

Hierarchy:
Subscriptions > Resource Group > Resource


# Answer B9

A company might place related Azure resources in the same resource group because it makes it easier to track. A company will have a huge codebase and if the resources are separated the tracking would be a lot difficult. Also when related resources are separated then it's difficult to work for any person who is assigned to the work to make any changes to it. Which leads to giving access to multiple resources to the same person.