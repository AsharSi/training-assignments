import json

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("urban_mobility.csv")

print(df.iloc[:5])

df['Energy_Per_Km'] = df['Energy_Used_kWh'] / df['Distance_Km']

print(df['Energy_Per_Km'])

print(df[(df['Vehicle_Type'] == 'Electric Van') & (df['Maintenance_Flag'] == 'Yes')])

print(df.groupby('Vehicle_Type').agg(Avg_Distance_Km=('Distance_Km', 'mean'), Total_Trips_Count=('Trips_Count', 'sum')).reset_index())

print(f"Mean: {df['Energy_Used_kWh'].mean().round(2)}\nMax: {df['Energy_Used_kWh'].max()}\nMin: {df['Energy_Used_kWh'].min()}")

grouped_df = df.groupby('Vehicle_Type')['Energy_Used_kWh'].mean()

grouped_df.plot(kind='bar')

plt.xlabel('Vehicle Type')
plt.ylabel('Energy Used (kWh) (mean)')

plt.show()

try:
    with open('equipment_events.json') as json_file:
        equipment_events = json.load(json_file)
except FileNotFoundError:
    print("File not found")

for event in equipment_events:
    print(f"{event["event_id"]} | {event["asset"]["type"]} | {event["asset"]["site"]}| {event["severity"]}")

print("Records temperature above 70")
for event in equipment_events:
    if event["temperature"] > 70:
        print(event)

print("Checking weather action is missing or not")

for event in equipment_events:
    if "actions" not in event:
        print("No actions recorded: ", event["event_id"])

with open("coastal_monitoring_log.txt") as f:
    texts = f.read()

words = texts.lower().split()
lines = texts.split("\n")

print("Count of word inspection: ", words.count("inspection"))

for line in lines:
    if "boardwalk" in line:
        print(line)
    elif "maintenance" in line:
        print(line)
    elif "wind" in line:
        print(line)
